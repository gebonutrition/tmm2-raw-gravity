# TMM2 Raw Gravity

Production-ready static landing:
- one `index.html`
- responsive desktop / tablet / mobile
- Klaviyo API under `/api/subscribe`
- TikTok + Meta attribution
- GA4 placeholder in `index.html`
- Amazon source mapping copied from wellness1

Vercel env:
- `KLAVIYO_API_KEY`
- `KLAVIYO_LIST_ID`

Before production:
1. Replace `GA_MEASUREMENT_ID` in `index.html` with the actual TMM2 GA4 Measurement ID.
2. Put the four fan images into `assets/fan-1.png` ... `assets/fan-4.png` (already included in this package).
